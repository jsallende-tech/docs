package com.worldline.wpi_codelab.model.response

import kotlinx.serialization.Serializable

@Serializable
public data class SaleTransactionResponse(
    val result: String?,
    val authorizedAmount: Long? = null,
    val currency: String? = null,
)