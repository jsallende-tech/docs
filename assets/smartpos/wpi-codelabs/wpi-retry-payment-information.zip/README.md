# Sample WPI Payment information

This repository contains sample code for the WPI Payment information project.

## Branches

- **master**: Contains the starting code for this sample.
- **end**: Contains the final code after completing all steps.

## Codelab Generation

To generate a codelab zip:

1. Ensure the project is clean:
    - Remove all build artifacts and temporary files.
    - Exclude the following directories from the zip:
        - `build`
        - `.idea`
        - `.kotlin`
2. The zip archive **must include the `.git` directory** to preserve git history and branches.

This ensures a clean and reproducible environment for codelab participants.