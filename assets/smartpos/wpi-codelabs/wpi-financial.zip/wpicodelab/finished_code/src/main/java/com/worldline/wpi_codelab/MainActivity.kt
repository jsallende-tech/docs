package com.worldline.wpi_codelab

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.worldline.wpi_codelab.model.request.SaleTransactionRequest
import com.worldline.wpi_codelab.model.response.SaleTransactionResponse
import kotlinx.serialization.json.Json
import java.util.UUID

class MainActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        result.data?.let { handleTransactionResponse(it) }
    }

    //allows ignoring fields we don't need in the response
    private val json = Json { ignoreUnknownKeys = true }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SaleTransactionScreen { amount ->
                executeSaleTransaction(amount)
            }
        }
    }

    private fun executeSaleTransaction(amount: Long) {
        val saleTransaction = SaleTransactionRequest("eur", amount)
        val saleTransactionJson: String = Json.encodeToString(saleTransaction)

        val intent = Intent("com.worldline.payment.action.PROCESS_TRANSACTION")
        // These extras are mandatory whether the intent comes from the payment
        // application or a 3rd party application.
        intent.putExtra("WPI_SERVICE_TYPE", "WPI_SVC_PAYMENT")
        intent.putExtra("WPI_REQUEST", saleTransactionJson)
        intent.putExtra("WPI_VERSION", "2.1")
        // Session value is always up to the third party application
        // Random unique identifier of the current communication session
        // Can be used to restore the state of the transaction in multipart communication (e.g. product delivery)
        intent.putExtra("WPI_SESSION_ID", UUID.randomUUID().toString())

        launcher.launch(intent)
    }

    private fun handleTransactionResponse(intent: Intent) {
        val rawJsonResponse = intent.getStringExtra("WPI_RESPONSE")
        if (rawJsonResponse != null) {
            Log.d("Transaction response", rawJsonResponse)
            val transactionResponse = json.decodeFromString<SaleTransactionResponse>(rawJsonResponse)
            val paymentMessage = "${transactionResponse.result}: ${(transactionResponse.authorizedAmount?.toDouble()?.div(100))} ${transactionResponse.currency}"
            Toast.makeText(this, paymentMessage, Toast.LENGTH_SHORT).show()
            }
        // Handle response
    }
}
