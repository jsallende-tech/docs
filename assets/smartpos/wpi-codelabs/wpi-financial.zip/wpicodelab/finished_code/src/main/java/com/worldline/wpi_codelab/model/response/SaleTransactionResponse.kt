package com.worldline.wpi_codelab.model.response

import kotlinx.serialization.Serializable

@Serializable
data class SaleTransactionResponse(
    val result: String?,
    val authorizedAmount: Long? = null,
    val currency: String? = null,
)