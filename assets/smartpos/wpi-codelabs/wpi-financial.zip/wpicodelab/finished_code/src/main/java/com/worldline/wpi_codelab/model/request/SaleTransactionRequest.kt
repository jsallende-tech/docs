package com.worldline.wpi_codelab.model.request

import kotlinx.serialization.Serializable

@Serializable
public data class SaleTransactionRequest(
    val currency: String,
    val requestedAmount: Long,
)