package com.worldline.wpi_codelab

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaleTransactionScreen(
    onSubmit: (Long) -> Unit
) {
    val options = listOf(
        1999L to "19,99",
        12000L to "120",
        5000L to "50"
    )
    var selectedAmount by remember { mutableStateOf(options[0].first) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("WPI financial codelab") })
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                options.forEach { (amount, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = selectedAmount == amount,
                            onClick = { selectedAmount = amount }
                        )
                        Text(label)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = { onSubmit(selectedAmount) }) {
                    Text("Submit")
                }
            }
        }
    }
}
