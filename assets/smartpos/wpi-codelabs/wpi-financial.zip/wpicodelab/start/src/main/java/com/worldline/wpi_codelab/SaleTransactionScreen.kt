package com.worldline.wpi_codelab

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaleTransactionScreen(
    onSubmit: (Long) -> Unit
) {
    val options = listOf(
        1999L to "19,99",
        12000L to "120",
        5000L to "50"
    )
    var selectedAmount by remember { mutableStateOf(options[0].first) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("WPI financial codelab") })
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                options.forEach { (amount, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = selectedAmount == amount,
                            onClick = { selectedAmount = amount }
                        )
                        Text(label)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = { onSubmit(selectedAmount) }) {
                    Text("Submit")
                }
            }
        }
    }
}
